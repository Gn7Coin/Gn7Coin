MarteX-qt: Qt5 GUI for MarteX
===============================

Linux
-------
https://github.com/MarteXdev/MarteX/blob/master/doc/build-unix.md

Windows
--------
https://github.com/MarteXdev/MarteX/blob/master/doc/build-msw.md

Mac OS X
--------
https://github.com/MarteXdev/MarteX/blob/master/doc/build-osx.md
